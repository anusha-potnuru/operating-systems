#ifndef ELEM_H
#define ELEM_H
struct elem
{
    long procid;
    int prio;
};

#endif